#include <Arduino.h>

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"

// TSTOP => [1000, 7000]
// If surpassed the trace buffer won't have enough space to save every context change
// #define TSTOP 1000  // Time in milliseconds to stop the kernel
#define TSTOP 7000  // Time in milliseconds to stop the kernel

// Change to 1 if you want to create the graph with matlab instead of `graph.py`
#define MATLAB 0

void Task(void* pvParameters);
void Task9Scheduler(void* pvParameters);
void OneShotTimerCallback(TimerHandle_t xTimer);

void str_compute(unsigned long milliseconds);
void str_trace(void);
float str_getTime(void);

/// EDF task descriptor.
typedef struct {
    /// Name of the task.
    const char* const name;
    /// Function that contains the code of the task.
    const TaskFunction_t taskHandler;
    /// Maximum time the task will take to complete.
    const uint8_t compute_time;
    /// Maximum time the task should take to complete.
    const uint8_t deadline;
    /// Time between executions of the task.
    const uint8_t period;
    /// When the task was last activated.
    /// Should be used with 
    TickType_t lastWakeTime;
    uint8_t remaining_deadline;
    TaskHandle_t handle;
} TaskEDF_t;

typedef struct {
    TaskEDF_t* edf;
} TaskDeadline_t;

static TaskEDF_t Tasks[] = {
    {
        .name = "Task1",
        .taskHandler = Task,
        .compute_time = 2,
        .deadline = 15,
        .period = 30,
    },
    {
        .name = "Task2",
        .taskHandler = Task,
        .compute_time = 4,
        .deadline = 20,
        .period = 30,
    },
    {
        .name = "Task3",
        .taskHandler = Task,
        .compute_time = 10,
        .deadline = 35,
        .period = 40,
    },
    {
        .name = "Task4",
        .taskHandler = Task,
        .compute_time = 21,
        .deadline = 40,
        .period = 50,
    },
    {
        .name = "Task5",
        .taskHandler = Task,
        .compute_time = 5,
        .deadline = 50,
        .period = 50,
    },
};
const uint8_t N_SCHED_TASKS = sizeof(Tasks) / sizeof(TaskEDF_t);
const uint8_t N_TASKS = N_SCHED_TASKS + 1;

static TaskDeadline_t TaskDeadlines[N_SCHED_TASKS];
static TaskHandle_t TaskHandles[N_TASKS] = {};


const size_t BUFF_SIZE = ((float)TSTOP * 2.14);
// Time changed from `float` to `u16`, so `TSTOP` can be increased from 5500 to 7000.
// If you want to see the "real" time, you can change the type back to `float`.
// Remember to adjust `TSTOP` afterwards
static uint16_t t[BUFF_SIZE] = {};
// Circular buffer for debugging
static char circ_buffers[N_SCHED_TASKS][BUFF_SIZE] = {};
static size_t circ_buffer_counter = 0;

// Task handlers
static float systemStartupTime;
static float maxTraceTime = INT32_MIN;
static float accTraceTime = 0;
static float maxSchedTime = INT32_MIN;
static float accSchedTime = 0;

// Timer handlers
TimerHandle_t xPeriodicTimer, xOneShotTimer;
BaseType_t xPeriodicTimerStarted, xOneShotStarted;

void setup() {
    Serial.begin(115200);

    // create tasks based on Tasks array
    for (uint8_t i = 0; i < N_SCHED_TASKS; i++) {
        TaskEDF_t* task = &Tasks[i];
        xTaskCreate(task->taskHandler, task->name, configMINIMAL_STACK_SIZE, task, 1, &TaskHandles[i]);
        task->handle = TaskHandles[i];
        task->remaining_deadline = task->deadline;
        TaskDeadlines[i] = {.edf = task};
    }
    // create scheduler task
    xTaskCreate(Task9Scheduler, "Task9", configMINIMAL_STACK_SIZE, NULL, configMAX_PRIORITIES - 1, &TaskHandles[N_SCHED_TASKS]);

    // create and start timer to stop program execution
    xOneShotTimer = xTimerCreate("OneShotTimer", pdMS_TO_TICKS(TSTOP), pdFALSE, 0, OneShotTimerCallback);
    xOneShotStarted = xTimerStart(xOneShotTimer, 0);

    // start running
    vTaskStartScheduler();
}

void loop() {}

void Task(void* pvParameters) {
    // get task parameters
    TaskEDF_t *const task = static_cast<TaskEDF_t* const>(pvParameters);

    for (;;) {
        // waste time
        str_compute(task->compute_time);

        // wait until start of next period
        vTaskDelayUntil(&task->lastWakeTime, pdMS_TO_TICKS(task->period));
    }
}

/// Prints a message indicating that the provided task has missed its deadline and aborts the program execution.
/// The function needs the attributes, as if inlined into the only caller (Task9Scheduler), all tasks will start missing their deadlines.
/// This is probably due to taking too much space in the code cache, and making other code slower.
/// As the CPU utilization is 97%, a small performance penalty can greatly affect the final program.
///
/// You can check that the deadline detection works correctly by increasing the compute_time of a task a lot.
_Noreturn _NOINLINE_STATIC __attribute__((cold)) void deadlineMissed(TaskEDF_t* edf, TickType_t now) {
    // wait a bit for Serial to initialize if it hasn't
    str_compute(500);

    // print task info
    Serial.print(edf->name);
    Serial.println(" missed deadline");
    Serial.print("Deadline: ");
    Serial.println((uint32_t)edf->lastWakeTime + edf->deadline);
    Serial.print("Now: ");
    Serial.println((uint32_t)now);
    Serial.println("###");

    // stop the timer and abort the system
    xTimerStop(xOneShotTimer, 0);
    OneShotTimerCallback(NULL);

    for (;;);
}

void updateTasks() {
    TickType_t now = xTaskGetTickCount();

    for (uint8_t i = 0; i < N_SCHED_TASKS; i++) {
        TaskEDF_t* edf = TaskDeadlines[i].edf;
        // update remaining deadline of all tasks
        eTaskState state = eTaskGetState(edf->handle);
        if (state == eReady || state == eRunning) {
            if (edf->remaining_deadline > 0)
                edf->remaining_deadline -= 1;
            else
                deadlineMissed(edf, now);
        }
        // if task period should begin, reactivate task
        if (now - edf->lastWakeTime >= edf->period) {
            edf->remaining_deadline = edf->deadline;
        }
    }
}

void sortTasks() {
    for (int i = 1; i < N_SCHED_TASKS; i++) {
        TaskDeadline_t key = TaskDeadlines[i];
        int j = i - 1;

        uint8_t key_remaining = key.edf->remaining_deadline;

        // move elements that are greater than `key.remaining_deadline` one position ahead
        while (j >= 0 && TaskDeadlines[j].edf->remaining_deadline > key_remaining) {
            TaskDeadlines[j + 1] = TaskDeadlines[j];
            j--;
        }
        TaskDeadlines[j + 1] = key;
    }
}

void setTaskPriorities() {
    for (uint8_t i = 0; i < N_SCHED_TASKS; i++) {
        vTaskPrioritySet(TaskDeadlines[i].edf->handle, configMAX_PRIORITIES - 2 - i);
    }
}

void Task9Scheduler(void* arg) {
    (void)arg;

    systemStartupTime = str_getTime();

    for (;;) {
        float startTime = str_getTime();

        // update task remaining deadlines and check for missed ones
        updateTasks();

        // sort tasks by remaining deadline
        // must be in a separate function, if not, tasks will miss deadline
        sortTasks();

        // assign priorities accordingly
        setTaskPriorities();

        float time = str_getTime() - startTime;
        accSchedTime += time;
        maxSchedTime = max(maxSchedTime, time);

        vTaskSuspend(NULL);
    }
}

void vApplicationTickHook(void) {
    // resume scheduler and yield immediately
    BaseType_t yield_required = xTaskResumeFromISR(TaskHandles[N_SCHED_TASKS]);
    portYIELD_FROM_ISR(yield_required);
}

void vApplicationStackOverflowHook(TaskHandle_t xTask, char* pcTaskName) {
    Serial.println(pcTaskName);
    for (;;);
}

void OneShotTimerCallback(TimerHandle_t xTimer) {
    str_trace();
    // Stop the kernel...
    vTaskSuspendAll();
    str_trace();
    vPortEndScheduler();

    //...and sent data to the host PC
    size_t i;
    for (i = 3; i < BUFF_SIZE; i++) {
        if (i > 5 && t[i] == 0) break;

        Serial.println("DAT");
        Serial.print((float)t[i]);
        for (uint8_t t = 0; t < N_SCHED_TASKS; t++) {
            Serial.print(",");
            Serial.write(circ_buffers[t][i]);
        }
        Serial.println();
    }

    #if !MATLAB
    {
        Serial.println("---");
        Serial.print("Samples: ");
        Serial.println(i);
    
        Serial.print("System Startup Time: ");
        Serial.println(systemStartupTime);
    
        Serial.print("Max Trace Time: ");
        Serial.println(maxTraceTime, 10);
        Serial.print("Acc Trace Time: ");
        Serial.println(accTraceTime, 2);
    
        Serial.print("Max Sched Time: ");
        Serial.println(maxSchedTime, 10);
        Serial.print("Acc Sched Time: ");
        Serial.println(accSchedTime, 2);
    }
    #endif

    for (;;);
}

// str_getTime is a custom implementation of the time to debug data
float str_getTime(void) {
    // clear all;
    // SystemCoreClock=64000000%From Serial.println(SystemCoreClock);
    // configSYSTICK_CLOCK_HZ=SystemCoreClock
    // configTICK_RATE_HZ=100;
    // portNVIC_SYSTICK_LOAD_REG = ( configSYSTICK_CLOCK_HZ / configTICK_RATE_HZ );% - 1
    // tick2milliseconds=1/configTICK_RATE_HZ*1000/portNVIC_SYSTICK_LOAD_REG
    // vpa(tick2milliseconds,20)

    // #define portNVIC_SYSTICK_CURRENT_VALUE_REG    ( *( ( volatile uint32_t * ) 0xe000e018 ) )
    volatile uint32_t portNVIC_SYSTICK_CURRENT_VALUE_REG = (*((volatile uint32_t*)0xe000e018));

    // float t=(float)micros() / 1000.f;//ok
    // float t=millis();//not so precise
    float t = 0.0000015625 * ((640000 - portNVIC_SYSTICK_CURRENT_VALUE_REG) + xTaskGetTickCount() * 640000);
    //(float)(0.5e-3*((float)OCR1A*xTaskGetTickCount()+TCNT1));//Sent time in milliseconds!!!
    return t;
}

// str_compute(x) is only used to waste time without using delays
void str_compute(unsigned long milliseconds) {
    unsigned int i = 0;
    unsigned int imax = 0;
    imax = milliseconds * 3275;
    volatile float dummy = 1;
    for (i = 0; i < imax; i++) {
        dummy = dummy * dummy;
    }
}

// str_trace is a hook by the RTOS kernel used after a context-switch-in
void str_trace(void) {
    float startTime = str_getTime();

    circ_buffer_counter++;
    if (circ_buffer_counter >= BUFF_SIZE) {
        circ_buffer_counter = 0;
    }

    t[circ_buffer_counter] = str_getTime();  // sent time in milliseconds
    for (int i = 0; i < N_SCHED_TASKS; i++) {
        #if MATLAB
        const char offset = 0;
        #else
        const char offset = '0';
        #endif
        circ_buffers[i][circ_buffer_counter] = eTaskGetState(TaskHandles[i]) + offset;
    }

    // workaround to get Scheduler Task in the graph to work properly
    // circ_buffers[N_SCHED_TASKS][circ_buffer_counter] = eTaskGetState(TaskHandles[N_SCHED_TASKS]) == eSuspended ? '2' : '0';

    float time = str_getTime() - startTime;
    accTraceTime += time;
    maxTraceTime = max(maxTraceTime, time);
}
